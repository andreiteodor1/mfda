# H4F — adaptation for “From a Business Problem to an Information System”

Status: adapted working draft using your confirmed choices: full national platform, 2027 Work Plan, original KPI targets with baselines marked “not measured,” and a newly modeled current process. All numbered requirements below are English formulations of capabilities already described in the archive; they are not claims that a working system exists. New scenario content is labeled separately from archive evidence. Missing detailed policies and measurements remain explicitly open.

The original project is H4F (Health for Future), a proposed Romanian medical-data interoperability platform with a national vision. It connects existing medical systems, gives patients a unified medical history and control over sharing, supports authorized clinical access, and protects access through audit and security monitoring. The documented launch scenario is a pilot involving 10 public/private medical units in 2 counties.

The archive is mainly a project-management proposal. The new assignment needs a business-analysis view of the same theme: how information moves between institutions, who needs it, what controls apply and how value will be measured. Development phases, staffing and algorithm architecture provide supporting context; they do not replace functional requirements.

## Evidence and version handling

The archive was extracted outside the mfda repository, including the nested MP 2.zip. It contains 34 Word files with 21 distinct extracted main texts, 20 PDFs and supporting visuals. Several are duplicates. The top-level Lab/Project_Handbook.docx and Lab/Project_WorkPlan.docx are unfilled PM² templates. The completed H4F versions are inside Documente_proiect. Template instructions were treated as document content, not as your instructions.

No authoritative version was selected silently. Shared facts underpin this draft. S7/S8/S9 contain the expanded security scope, already present in the archive. Their detailed algorithms are supporting design material, while FR09/FR10 describe the business-facing behavior.

## What is established and what is missing

Established: records are stored in separate, non-interconnected hospital, clinic, laboratory and pharmacy systems. The proposal associates this fragmentation with information loss, delays, repeated investigations and a difficult patient experience. These are claims made by the project proposal; the archive does not provide an empirical national baseline.

The archive does not define the exact present-day record-sharing procedure. You authorized a modeled solution for this gap. The following is a realistic classroom scenario newly added for the adaptation, not a verified description of every Romanian institution:

1. A patient attends a consultation at a different institution, and the clinician identifies a need for prior results or treatment information.
2. The patient gathers available medical documents or requests copies from the originating hospital, clinic or laboratory.
3. Staff at the originating institution locate the information in their local system and provide the patient with the available documents after the institution's applicable checks.
4. The patient presents available paper copies or electronic documents at the next consultation.
5. The receiving professional manually reviews and reconciles the information with the local record. Missing or delayed information can delay decisions and contribute to repeated investigations, as the original project describes.

Illustrative document types are consultation/discharge summaries, laboratory reports, imaging reports and prescriptions. These are a proposed representation of information already named in the archive, not a claim that the source defines those exact document formats. No transfer-time estimate, legal exception or guaranteed repetition of a test is assumed.

The proposed functional sequence can be summarized from the documented capabilities: participating systems supply information → H4F associates it with a patient → access and consent controls govern viewing → access is audited and monitored. This is a synthesis of the proposed capabilities, not a fully agreed operational workflow or DFD.

## Business needs and scope

- Continuity of information: make relevant existing medical history available to authorized professionals.
- Patient trust and control: allow patients to view their information and control sharing.
- Operational efficiency: address delays and unnecessary repeat investigations associated with fragmented records; no numeric benefit is evidenced.
- Adoption and sustainability: validate the platform with participating medical units, satisfaction and retention measures.

Confirmed semester boundary: analyze the full national H4F platform, including patient indexing, unified information access, consent, authorized exchange, audit and security monitoring across participating Romanian institutions. Existing HIS/LIS/RIS remain external systems. The 10-unit, 2-county pilot is a 2027 rollout milestone, not the system boundary. European expansion remains a longer-term ambition. The 2027 plan does not establish completed nationwide coverage within that year. CNAS and pharmacy connections are potential integrations, not confirmed agreements or completed interfaces. Billing workflows, emergency overrides, retention schedules and detailed legal access rules are not defined in the archive.

## Stakeholders and business roles

| Role | Responsibilities supported by the archive | Source |
| --- | --- | --- |
| Patient | Consults personal medical information, determines sharing consent and provides feedback. | S1, S3, S6 |
| Medical professional | Uses relevant medical history to support care and helps validate the clinical usefulness of the platform. | S1, S3 |
| Participating hospital / clinic representative | Supports integration, local adoption, staff training and clinical feedback. | S3, S4 |
| HIS/LIS/RIS supplier or integration specialist | Connects existing medical systems and supports compatibility of information exchange. | S3, S4 |
| Security / operations specialist | Monitors activity, investigates alerts and supports incident response and service continuity. | S7, S9 |
| Data Protection Officer / privacy oversight | Reviews data flows and access policies for GDPR compliance. | S5, S8 |
| H4F business management | Coordinates adoption and evaluates project objectives, sustainability and stakeholder needs. | S3, S9 |

## Functional requirements

| ID | The system must… | Relevant roles | Source | Unresolved detail |
| --- | --- | --- | --- | --- |
| FR01 | Maintain a unified patient index so records from participating institutions can be associated with the same patient. | Participating institutions; integration team | S4, S6 | Identity fields, matching and duplicate-resolution policy are not specified. |
| FR02 | Consolidate consultations, diagnoses, laboratory results, imaging information, treatments and prescriptions into a unified patient medical record. | Patients; medical professionals | S1 | Physical storage versus linked source records and document formats are not fully defined. |
| FR03 | Allow patients to view their own unified medical history. | Patients | S1, S6 | Authentication and patient identification procedures are not specified. |
| FR04 | Allow patients to specify which medical information may be accessed and by whom. | Patients | S1, S6 | Consent duration, withdrawal and exceptional access are not defined. |
| FR05 | Allow authorized medical professionals to consult relevant patient history under the applicable access and consent rules. | Medical professionals | S1, S8 | The detailed role-permission matrix and exceptional access policy are not defined. |
| FR06 | Exchange medical information with the existing systems of participating healthcare institutions. | Institutions; HIS/LIS/RIS suppliers | S1, S3, S4 | Exchange direction, event triggers and error-handling rules require definition. |
| FR07 | Record access to medical information in an audit trail identifying who accessed what and when. | Security team; privacy oversight | S5, S6 | Retention period and precise audit fields are not defined. |
| FR08 | Make medical-data access history available for patient transparency and audit oversight. | Patients; authorized auditors | S6, S8 | The canvas supports patient audit transparency; auditor permissions require definition. |
| FR09 | Monitor access activity, detect suspicious behavior and generate security alerts. | Security team | S1, S7, S9 | Detection thresholds, severity levels and alert recipients are not specified. |
| FR10 | Support automated responses to security incidents, including session blocking and escalation. | Security team | S7, S9 | Conditions for automatic intervention and escalation authority are not specified. |

## Business rules and constraints

The archive provides high-level access rules and security/interoperability constraints rather than a complete operational rulebook. The following formalizes those existing statements. Approval thresholds, emergency overrides and document-retention periods have not been invented.

| ID | Type | Required rule / constraint | Related functions | Source | Missing detail |
| --- | --- | --- | --- | --- | --- |
| BC01 | Access rule | Medical information must be accessible only to authorized users under the applicable access policies. | FR05, FR06 | S1, S8 | Exact role permissions and emergency exceptions are missing. |
| BC02 | Consent rule | Access must respect the patient-defined scope of information and recipients where the project consent rules apply. | FR04, FR05 | S1, S6, S8 | The archive does not define every legal basis for access or emergency access. |
| BC03 | Audit rule | Access to medical information must be traceable in a complete audit trail. | FR07, FR08 | S5, S6 | Audit retention and access permissions are missing. |
| BC04 | Interoperability constraint | Medical-data exchange flows must conform to HL7/FHIR as required by the project quality plan. | FR02, FR06 | S5, S8 | FHIR version, profiles and validation policy are missing. |
| BC05 | Confidentiality constraint | Medical information must be protected using encryption and controlled access. | FR02, FR05, FR06 | S1, S5, S6 | Detailed encryption and key-management policies are not specified. |
| BC06 | Data-protection constraint | Security analytics must apply data minimization, pseudonymization and separation of responsibilities, using primarily security telemetry and metadata. | FR09, FR10 | S7 | The precise data categories and permitted exceptions are not defined. |

Separate non-functional requirements from S5/S8: platform availability at least 99.9%; API response time below 500 ms. The source does not specify a measurement window, workload, exclusions or percentile. These require agreement before objective acceptance testing. They are targets, not measured results.

## Preliminary inventory of information assets

This is an inventory of business information, not a database schema. Source/consumer summaries synthesize the documented roles and capabilities; exact field definitions, ownership, access and retention remain to be agreed. Imaging information does not imply a confirmed requirement to store full image files. Project evaluation information does not imply that H4F must automatically collect surveys or generate management reports.

| ID | Information asset | Origin / flow | Business use | Information level | Source | Still to define |
| --- | --- | --- | --- | --- | --- | --- |
| IA01 | Patient identity / index entries | Participating institutions → patient index | Associate records with a patient | Operational | S4, S6 | Patient identity fields and reconciliation rules |
| IA02 | Consultation history | Healthcare institutions → unified record | Support continuity of care | Operational | S1 | Consultation fields and update authority |
| IA03 | Diagnoses | Healthcare institutions → unified record | Inform medical decisions | Operational | S1 | Coding system and validation rules |
| IA04 | Laboratory results | Laboratories / LIS → unified record | Make prior results available | Operational | S1, S3 | Units, reference ranges and result-validation policy |
| IA05 | Imaging information | Imaging services / RIS → unified record | Make prior investigations available | Operational | S1, S3 | Reports versus image files; storage and exchange formats |
| IA06 | Treatments | Healthcare institutions → unified record | Provide treatment history | Operational | S1 | Treatment status and update authority |
| IA07 | Prescriptions | Medical systems; potential pharmacy/eRețeta connection | Provide prescription history | Operational | S1, S3 | Issuing, dispensing and cancellation responsibilities |
| IA08 | Patient consent records | Patients → consent mechanism | Control permitted information access | Operational | S1, S4, S6 | Duration, withdrawal, recipients and exceptional access |
| IA09 | User identities and role permissions | Identity/access mechanisms → authorization | Enforce access policies | Operational | S8, S12 | Registration authority and role-permission matrix |
| IA10 | Institution and integration records | Participating institutions / HIS-LIS-RIS suppliers | Manage participating connections | Operational | S3, S4, S6 | Institution identifiers and integration-status definitions |
| IA11 | Access audit logs | Platform access events → audit trail | Provide who/what/when traceability | Operational / oversight | S5, S6 | Retention, viewers and detailed event schema |
| IA12 | Security telemetry and metadata | Gateway / infrastructure / database activity | Detect suspicious behavior | Operational | S7, S9 | Collected fields, permitted uses and retention |
| IA13 | Security alerts and incident information | Detection / response components → security team | Support incident handling | Operational / oversight | S7, S9 | Severity, response ownership and escalation criteria |
| IA14 | User feedback and satisfaction results | Pilot users / institutions → project evaluation | Evaluate usefulness and adoption | Management | S2, S4 | Survey method, scoring and sample |
| IA15 | Platform service measurements | Platform monitoring → operational evaluation | Evaluate availability and response performance | Operational / management | S5, S8 | Measurement window, load and percentile definition |
| IA16 | Pilot and adoption evaluation reports | Pilot integration and feedback activities | Support rollout and business decisions | Management | S2, S4 | Exact report fields and retention cohort |

## Potential external integrations and organizations

All entries are proposed or potential. No archive evidence establishes a working interface, granted access or signed partnership.

| External system | Organization / partner | Purpose | Source |
| --- | --- | --- | --- |
| Hospital / clinic HIS | Medical institutions and software suppliers | Potential exchange of patient clinical history | S1, S3, S4 |
| Laboratory LIS | Laboratories and software suppliers | Potential exchange of laboratory information | S1, S3, S4 |
| Radiology RIS | Imaging services and software suppliers | Potential exchange of imaging information | S1, S3, S4 |
| CNAS / PIAS / health card | National Health Insurance House | Potential interoperability and reimbursement-related reporting | S3 |
| Pharmacy systems / eRețeta | Pharmacies and pharmacy networks | Potential exchange of relevant prescription information | S3 |

## Business objectives and KPIs

These numeric targets come from the original project. At your direction, baselines are marked “not measured”; no zero baseline or achieved improvement is assumed. Measurement definitions below remain open; no new target or empirical result has been introduced.

| ID | Indicator | Baseline | Documented target | Horizon | Source | Measurement gap |
| --- | --- | --- | --- | --- | --- | --- |
| K01 | User satisfaction | Not measured | At least 80% | During pilot evaluation | S2 | Survey scale, population and aggregation are undefined. |
| K02 | Medical-unit retention | Not measured | At least 70% | After the first 3 months of use | S2 | Cohort, active-use criteria and treatment of trials are undefined. |
| K03 | Integrated pilot medical units | Not measured | 10 units in 2 counties | 2027 pilot launch: December 1–15, per selected Work Plan | S2, S10 | Definition of completed integration requires agreement. |
| K04 | Business-model validation participants | Not measured | At least 30 units in paid pilot or trial | Deadline to redefine against the selected 2027 plan | S2, S10 | Keep the original quantity; obsolete end-of-2026 deadline is not retained. Distinct from K03. |
| K05 | H4F Ready partners | Not measured | At least 3 certified partners | Original relative objective: within 8 months | S2 | Partner acceptance criteria and alignment to the 2027 plan require definition. |

K01 and K02 address user acceptance and sustainability; K03 measures adoption. They do not directly quantify clinical improvement or cost savings. The project expects faster information access and fewer repeated investigations but provides no baseline or target for those outcomes. Per your choice, no additional numeric targets are introduced. The 10-unit launch pilot, 30-unit business-validation goal and 3 integration partners are different populations and milestones.

## Assignment coverage

| Teacher requirement | Adapted content | Location | Evidence / gap |
| --- | --- | --- | --- |
| 1. Business context | Romanian healthcare; public and private medical institutions | Slide 1; business case | S1, S3 |
| 2. Problem statement | Fragmented information, delays and repeated investigations | Slides 1–2; business case | S1 + user-authorized modeled current process |
| 3. Proposed solution | Unified medical information, consent, secure exchange | Slide 2; business case | S1, S4, S6 |
| 4. At least 4 roles | 7 roles with responsibilities | Slide 3; roles table | S1, S3, S5, S9 |
| 5. 6–10 functional requirements | 10 functional requirements | Slide 4; FR01–FR10 | Source references per row |
| 6. At least 10 information types | 16 preliminary information assets | Slide 6; IA01–IA16 | Source references per row |
| 7. At least 2 integrations / partners | HIS, LIS, RIS; potential CNAS and pharmacy links | Slide 5; integrations table | S1, S3, S4 |
| 8. At least 5 rules / constraints | 6 access, privacy, audit and interoperability controls | Slide 7; BC01–BC06 | Source references per row |
| 9. At least 3 KPIs | Satisfaction, retention and pilot integration; 2 further targets | Slide 8; K01–K05 | S2; baselines absent |

## Confirmed adaptation decisions and remaining gaps

1. Scope: full national platform, as you selected. The pilot is a rollout milestone. No specific counties or hospitals are named.
2. Present process: never defined in the original; the modeled patient-mediated process above is newly added with your authorization.
3. Timeline: retain the 2027 Work Plan. Analysis/planning runs January 1–February 15; development February 16–June 30; integration July–September; testing October–November; pilot launch and monitoring December 1–15. The inherited end-of-2026 business-validation deadline is not used. The 30-unit target needs a revised milestone; no replacement date is invented.
4. KPIs: keep the documented targets and mark baselines “not measured,” as you selected. No invented time/cost reduction is claimed.
5. Later requirements detail: consent lifetime/withdrawal, exceptional access, user registration, matching of patients, data correction rights, retention, FHIR profiles and security escalation criteria are not defined. They are open analysis items, not silently added rules.

Other document issues: activity visuals show 16 weeks for A2 and 4 weeks for A5, whereas the activity lists show 20 and 2 weeks. The €935,000 budget is an estimate in S11, not validated expenditure or ROI. The Work Plan's detailed human-resource cost rows total €803,000, compared with €650,000 in the summary budget; those views require reconciliation before a financial claim. The canvas proposes subscriptions, integration fees, usage fees and professional services, but does not set prices. General references to “HL7/FHIR certification” do not identify a specific certification scheme. None of these details has been resolved by guessing.

## Study concepts applied to H4F

- Business process: cross-institution use of medical information to support patient care. Software functions such as viewing a record or recording consent support parts of that process.
- Operational information: individual records, consent decisions, access events and security alerts used in daily work.
- Management information: aggregate adoption, satisfaction, retention and service measurements used to evaluate rollout and value.
- Business requirement: enable more efficient, trusted access to relevant medical history. Functional requirement: the system allows authorized viewing. Non-functional requirement: a documented availability target. Business rule: access must respect applicable authorization and consent policies.
- Stakeholder: a person or organization affected by H4F, including regulators who need not be application users.
- Information asset: a valuable body of information such as a medical history or audit trail; an asset is not automatically a database table or a document format.
- Boundary: H4F performs its information-sharing and control functions while participating institutions keep operating their existing medical systems.
- KPI: a defined measure used to evaluate business value; an original target is not evidence of an achieved improvement.

## Source catalog

- **S1 — Project idea:** [Ideea_proiectului_H4F.docx](../original/Lab/Documente_proiect/Ideea_proiectului/Ideea_proiectului_H4F.docx)
- **S2 — Original objectives:** [Obiectivele_proiectului_H4F.docx](../original/Lab/Documente_proiect/Obiective/Obiectivele_proiectului_H4F.docx)
- **S3 — Stakeholder list:** [Lista_stakeholderi_H4F.docx](../original/Lab/Documente_proiect/Lista_stakeholderi/Lista_stakeholderi_H4F.docx)
- **S4 — Original activity list:** [Lista_activitati_H4F.docx](../original/Lab/Documente_proiect/Lista_de_activitati/Lista_activitati_H4F.docx)
- **S5 — Original quality plan:** [Planificare, asigurare si controlul calitatii.docx](../original/Lab/Documente_proiect/Planificare_asigurare_control_calitate/Planificare,%20asigurare%20si%20controlul%20calitatii.docx)
- **S6 — Business Model Canvas:** [Business Model Whiteboard.png](../original/Lab/Documente_proiect/Business_canvas/Business%20Model%20Whiteboard.png)
- **S7 — Expanded project idea:** [H4F_Ideea_proiectului.docx](../original/Lab/Documente_proiect/Daria_MP/MP/Ideea_proiectului/H4F_Ideea_proiectului.docx)
- **S8 — Expanded quality plan:** [H4F_Plan_Control_Calitate.docx](../original/Lab/Documente_proiect/Daria_MP/MP/Planificare_asigurare_control_calitate/H4F_Plan_Control_Calitate.docx)
- **S9 — Completed Project Handbook:** [H4F_Project_Handbook.docx](../original/Lab/Documente_proiect/Handbook_WorkPlan/H4F_Project_Handbook.docx)
- **S10 — Completed Project Work Plan:** [H4F_Project_WorkPlan.docx](../original/Lab/Documente_proiect/Handbook_WorkPlan/H4F_Project_WorkPlan.docx)
- **S11 — Original budget:** [BUGETUL PROIECTULUI.docx](../original/Lab/Documente_proiect/Buget/BUGETUL%20PROIECTULUI.docx)
- **S12 — Expanded objectives:** [H4F_Obiectivele_proiectului.docx](../original/Lab/Documente_proiect/Daria_MP/MP/Obiective/H4F_Obiectivele_proiectului.docx)
