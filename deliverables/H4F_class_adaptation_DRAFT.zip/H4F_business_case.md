# H4F — One-page business case

ADAPTED DRAFT • National scope / 2027 plan / original KPI targets

**Business context and need**

H4F (Health for Future) is a proposed Romanian healthcare information-sharing platform serving patients, medical professionals and public/private medical institutions. The original project describes medical records held in separate hospital, clinic, laboratory and pharmacy systems, without unified access. It links this fragmentation to information loss, delays, repeated investigations and difficulties for patients. The original archive supplies no measured baseline. The analysis adds a modeled process: patients request copies from originating institutions and present available documents for manual review at the next consultation. This scenario is illustrative.

**Proposed solution and boundary**

H4F would associate information with a unified patient record and support secure exchange between existing medical systems. Patients would view their medical history and control sharing; authorized professionals would consult relevant information. Access would be audited and monitored for suspicious activity. Existing institutional systems remain external. The proposed system has national scope. The selected 2027 Work Plan provides a launch pilot of 10 medical units in 2 counties; that is a rollout milestone, not the system boundary or a promise of completed nationwide deployment.

**Stakeholders and business model**

Patients provide consent and feedback; professionals use relevant medical history; participating institutions and HIS/LIS/RIS suppliers support integration; security specialists and privacy oversight protect information use. H4F management coordinates adoption and evaluates value. Potential connections include hospital, laboratory and radiology systems, CNAS/PIAS and pharmacy/eRețeta systems. The canvas proposes institutional subscriptions, integration and usage fees, and professional services. It supplies no prices or confirmed commercial agreements.

**Expected value and measures**

The expected benefits are more accessible medical history, fewer avoidable repeat investigations, stronger patient control and sustainable institutional adoption. Documented targets include at least 80% user satisfaction, at least 70% medical-unit retention after 3 months, and 10 integrated units in 2 counties at the December 2027 pilot milestone. Baselines are marked ‘not measured’; no measured baselines or quantified time/cost savings are supplied. Survey design, retention criteria and integration acceptance remain to be defined.

**Feasibility, controls and open decisions**

The original summary estimates €935,000 including contingency; this is not a validated cost or ROI and detailed resource costs need reconciliation. Key dependencies are institutional cooperation, compatible exchange, staff adoption, security and GDPR compliance. Documented controls include authorization, consent, traceability, encryption and HL7/FHIR exchange. The selected 2027 plan supersedes the inherited end-of-2026 business-validation deadline; a revised date for the separate 30-unit target remains undefined. Detailed access policies, integration acceptance and measurement definitions remain open. The modeled current process is a classroom scenario, not an observed national procedure.

Sources: S1–S6, S9–S11. Source keys and unresolved details are listed in H4F_analysis_and_requirements.md.
