# H4F — 8-slide presentation structure

Adapted working draft using user-confirmed national scope, the 2027 plan and original targets. A newly modeled current process is labeled explicitly.

## Slide 1 — H4F | Health for Future

From fragmented medical records to trusted information sharing

**Business context**

- Romanian healthcare: hospitals, clinics, laboratories and pharmacies.
- Patients and professionals need relevant medical history across institutions.
- National platform scope; 2027 launch pilot: 10 units in 2 counties.

**Business problem**

- Separate, non-interconnected systems fragment patient information.
- The project describes delays, information loss and repeated investigations.
- KPI baselines: not measured. A current-process scenario is modeled for class analysis.

Speaker notes / evidence: Adapted working draft. Scope confirmed by user: national platform, with a 2027 pilot rollout. The business problem is described by the proposal, not demonstrated by measured national evidence. Sources: S1, S2, S3.

## Slide 2 — The process and proposed solution

Improve access to existing medical information

**Current process — modeled scenario**

- A clinician identifies the need for prior medical information.
- The patient requests copies from the originating institution and presents available documents.
- Staff manually review the documents; missing information can delay care.

**H4F — proposed capability sequence**

- Connect participating institutions and associate records with a patient.
- Let patients view history and determine information-sharing consent.
- Provide authorized professional access, audit activity and monitor security.

Speaker notes / evidence: The current process is newly modeled with user authorization because the original never defined it. It is a classroom scenario, not a verified national procedure. Proposed steps synthesize documented H4F capabilities. Paper copies and electronic documents are illustrative formats. Expected benefits are improved continuity and efficiency; no reduction percentage is supplied. Sources: S1, S4, S6, S7.

## Slide 3 — Scope, stakeholders and responsibilities

Full national platform; 2027 pilot as a rollout milestone

**Care and institutional roles**

- Patient: view personal history, control sharing and give feedback.
- Medical professional: consult relevant history and validate clinical usefulness.
- Hospital / clinic representative: support integration, training and adoption.

**Control and delivery roles**

- HIS/LIS/RIS supplier: connect existing institutional systems.
- Security specialist and DPO: monitor access and review privacy controls.
- H4F business management: coordinate adoption and evaluate objectives.

Speaker notes / evidence: Documented 2027 pilot: 10 units in 2 counties. National scope was selected for analysis; European expansion remains a longer-term ambition. Existing medical systems stay external. The user selected full national platform scope and the 2027 Work Plan. Nationwide deployment is not claimed to finish with the pilot. Seven roles are separated in the companion analysis. Sources: S1–S6, S9.

## Slide 4 — What the system must do

10 functional requirements grounded in the archive

**Medical information and access**

- FR01  Associate records with a unified patient index.
- FR02  Consolidate patient medical history.
- FR03  Let patients view their medical information.
- FR04  Let patients specify sharing permissions.
- FR05  Let authorized professionals consult relevant history.

**Exchange, accountability and protection**

- FR06  Exchange data with existing medical systems.
- FR07  Record who accessed what and when.
- FR08  Make access history available for transparency and audit.
- FR09  Detect suspicious activity and generate security alerts.
- FR10  Support incident responses such as session blocking.

Speaker notes / evidence: These are capabilities, not implementation choices or completed features. Patient matching, role permissions, consent exceptions and incident thresholds remain undefined. Detailed formulations and sources: FR01–FR10 in the companion requirements table.

## Slide 5 — External systems and business partners

Potential integrations named in the original project

**Clinical information systems**

- Hospital / clinic HIS: clinical history exchange.
- Laboratory LIS: laboratory information exchange.
- Radiology RIS: imaging information exchange.

**Public and pharmacy connections**

- CNAS / PIAS / health card: potential interoperability and reporting.
- Pharmacy systems / eRețeta: relevant prescription information.
- These are proposed connections; access and partnerships are not confirmed.

Speaker notes / evidence: HIS = Hospital Information System; LIS = Laboratory Information System; RIS = Radiology Information System. CNAS is Romania’s National Health Insurance House. Direction, fields and interface contracts are not defined. Sources: S1, S3, S4.

## Slide 6 — Business information inventory

16 preliminary information assets; detailed inventory supplied

**Operational information**

- Patient index; consultations; diagnoses.
- Laboratory results; imaging information.
- Treatments; prescriptions; patient consent.
- User identities / roles; institution / integration records.
- Access audit logs; security telemetry; alerts / incidents.

**Management and oversight information**

- User feedback and satisfaction results.
- Service measurements: availability and response performance.
- Pilot and adoption evaluation reports.
- These support rollout and value decisions.
- Fields, ownership and retention remain to be defined.

Speaker notes / evidence: IA01–IA16 in the inventory. Audit and service measures also support operational oversight. Imaging information does not automatically mean full image-file storage. Evaluation documents do not imply an undocumented automatic reporting feature. Sources: S1–S9, S12 as detailed per row.

## Slide 7 — Business rules and constraints

Formalized from documented access and protection requirements

**Access and accountability**

- BC01  Only authorized users may access medical information.
- BC02  Access must respect applicable patient consent.
- BC03  Medical-information access must be traceable.

**Information protection and exchange**

- BC04  Exchange flows must conform to HL7/FHIR.
- BC05  Protect medical information with encryption and access controls.
- BC06  Minimize and pseudonymize data used in security analytics.

Speaker notes / evidence: Separate service targets: availability ≥99.9%; API response <500 ms (S5/S8), with measurement definitions missing. These six entries mix business rules and system constraints, as the assignment permits. Exact permissions, emergency access and retention are not supplied. Sources: S1, S5–S8.

## Slide 8 — Business value and measurable objectives

Original targets retained; baselines: not measured

**Three primary indicators**

- User satisfaction: at least 80% in pilot evaluation.
- Medical-unit retention: at least 70% after 3 months.
- Pilot adoption: 10 integrated units in 2 counties at the December 2027 milestone.

**Measurement gaps to resolve**

- Define the survey method, retention cohort and integration acceptance.
- No numeric retrieval-time or repeated-test baseline is provided.
- Use the 2027 plan. The separate 30-unit target needs a revised deadline.

Speaker notes / evidence: K01–K03 are the primary source-backed measures: acceptance, sustainability and adoption. The original 30-unit business-validation goal is distinct from the 10-unit launch pilot; the 3-partner API goal is another milestone. Per user instruction, the 2027 Work Plan is retained and baselines are marked not measured. Targets are not achieved results. Clinical/time/cost benefit is not quantified. Sources: S2, S10, S12.

