# H4F class adaptation — working draft

The original archive is extracted in ../original; the nested MP 2.zip is also extracted in ../nested. No source documents or repository files were changed.

Open H4F_analysis_and_requirements.md for the source-grounded understanding of the project and the explicitly labeled modeled current process, coverage of all nine teacher requirements, tables, source references, version conflicts, confirmed decisions and remaining detailed specification gaps.

Deliverables:

- H4F_presentation_DRAFT.pptx: editable 8-slide presentation with evidence and open questions in speaker notes.
- H4F_presentation_DRAFT.pdf: matching slide handout.
- H4F_slide_outline.md: editable presentation structure and speaker notes.
- H4F_business_case_DRAFT.pdf: verified single-page business case.
- H4F_business_case_DRAFT.docx: editable business case; pagination depends on the Word renderer.
- H4F_business_case.md: plain-text business case.
- H4F_requirements_and_information_inventory.xlsx: consolidated editable workbook with requirements, rules, information assets, KPIs, roles, integrations, assignment mapping and source catalog.
- functional_requirements.csv: 10 source-backed functional requirements.
- business_rules.csv: 6 documented rules / constraints.
- information_assets.csv: 16 preliminary information assets.
- KPIs.csv: 5 original targets with missing baselines and measurement gaps.

This working draft incorporates your answers: full national platform, the 2027 Work Plan, a newly modeled current process (authorized because the original never defined one), and documented targets with baselines marked not measured. The modeled process is explicitly distinguished from archive evidence. No new numeric targets or detailed access policies were invented. English follows the language of your request and assignment. It is not a final approved specification or evidence of an implemented application.
